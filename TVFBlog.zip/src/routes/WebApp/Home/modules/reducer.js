const initialState = {
  blah: false,
};

export default function homeReducer(state = initialState, action) {
  return state;
};
