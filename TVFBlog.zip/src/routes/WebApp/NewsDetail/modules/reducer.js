const initialState = {
  blah: false,
};

export default function newsDetailReducer(state = initialState, action) {
  return state;
};
