const initialState = {
  blah: false,
};

export default function newsReducer(state = initialState, action) {
  return state;
};
