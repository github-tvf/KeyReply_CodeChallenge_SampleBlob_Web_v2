const initialState = {
  blah: false,
};

export default function postReducer(state = initialState, action) {
  return state;
};
