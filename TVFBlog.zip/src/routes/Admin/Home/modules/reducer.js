const initialState = {
  blah: false,
};

export default function adminReducer(state = initialState, action) {
  return state;
};
