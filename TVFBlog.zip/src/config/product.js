export default {
  url: "",
  apiUrl: "/",
  realtimeService: false,
  realtimeServerAddress: "http://localhost:8901/"
}
