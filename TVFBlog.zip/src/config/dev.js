export default {
  url: "http://localhost:9000",
  apiUrl: "https://blob1api.act-mkt.com/",
  realtimeService: false,
  realtimeServerAddress: "http://localhost:8901/"
}
